package com.bridgeInvest.userservice.service.impl;

import com.bridgeInvest.userservice.constant.UserConstant;
import com.bridgeInvest.userservice.exception.UserException;
import com.bridgeInvest.userservice.model.entity.User;
import com.bridgeInvest.userservice.respository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/**
 * Custom UserDetailsService implementation that retrieves user information from UserRepository.
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {
    private final UserRepository repository;
    public UserDetailsServiceImpl(UserRepository repository) {
        this.repository = repository;
    }
    /**
     * Loads user details by username.
     *
     * @param email The username of the user.
     * @return The UserDetails object representing the user details.
     * @throws UsernameNotFoundException If user is not found.
     */
    @Override
    public UserDetails loadUserByUsername(String email){
        Optional<User> userInfo = repository.findByEmail(email);
        if (userInfo.isEmpty())
        {
            throw new UserException(HttpStatus.UNAUTHORIZED,UserConstant.INVALID_EMAIL_OR_PASSWORD);
        }
        return new org.springframework.security.core.userdetails.User(userInfo.get().getEmail(), userInfo.get().getPassword(),getAuthority(userInfo.get()));
    }

    private Set<SimpleGrantedAuthority> getAuthority(User user) {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
        user.getRoles().forEach(role -> {
            authorities.add(new SimpleGrantedAuthority("ROLE_" + role.getName()));
        });
        return authorities;
    }
}