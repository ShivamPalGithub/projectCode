package com.bridgeInvest.userservice.service;

import com.bridgeInvest.userservice.model.dto.EntityResponse;
import com.bridgeInvest.userservice.model.entity.Permission;
import java.util.List;
import java.util.UUID;

public interface PermissionService {
    EntityResponse fetchAllPermissions();

    EntityResponse fetchPermissionById(UUID id);
}
