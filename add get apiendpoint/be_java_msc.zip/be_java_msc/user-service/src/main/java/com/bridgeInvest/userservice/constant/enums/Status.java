package com.bridgeInvest.userservice.constant.enums;

public enum Status {
    DELETED(0),
    ACTIVE(1),
    INACTIVE(2);

    int statusValue;

    Status(int i) {
        statusValue = i;
    }
}
