package com.bridgeInvest.userservice.respository;

import com.bridgeInvest.userservice.model.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * UserRepository Interface which implements JpaRepository
 */
@Repository
public interface UserRepository extends  JpaRepository<User,UUID> {
	/**
	 *
	 * @param email
	 * @return
	 */
	Optional<User> findByEmail(String email);

	@Async
	 default CompletableFuture<List<User>> findAllAsync() {
		return CompletableFuture.supplyAsync(this::findAll);
	}

	List<User> findAll();
	public CompletableFuture<List<User>> findAllByEmail(String email);

}
 