package com.bridgeInvest.userservice.controller;

import com.bridgeInvest.userservice.constant.UserConstant;
import com.bridgeInvest.userservice.exception.UserException;
import com.bridgeInvest.userservice.model.dto.JwtRequestModel;
import com.bridgeInvest.userservice.model.dto.JwtResponseModel;
import com.bridgeInvest.userservice.service.impl.UserDetailsServiceImpl;
import com.bridgeInvest.userservice.utils.JwtUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller class for handling user authentication and generating JWT tokens.
 */
@RestController
@RequestMapping(value = "/api/V1/authentication")
public class AuthenticationController {

    private final AuthenticationManager authenticationManager;
    private final UserDetailsServiceImpl userDetailsServiceImpl;
    private final JwtUtils jwtUtils;
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationController.class);
    /**
     * parameterized constructor of AuthenticationController class
     * @param authenticationManager
     * @param userDetailsServiceImpl
     * @param jwtUtils
     */
    public AuthenticationController(AuthenticationManager authenticationManager, UserDetailsServiceImpl userDetailsServiceImpl, JwtUtils jwtUtils) {
        this.authenticationManager = authenticationManager;
        this.userDetailsServiceImpl = userDetailsServiceImpl;
        this.jwtUtils = jwtUtils;
    }

    /**
     * Generates a JWT token for the provided JWT request.
     *
     * @param jwtRequestModel The JWT request containing the username and password.
     * @return A ResponseEntity containing the generated JWT token.
     * @throws Exception If user authentication fails or the user is not found.
     */

    @PostMapping(value = "/login", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<JwtResponseModel> loginApi(@RequestBody JwtRequestModel jwtRequestModel) {
        try {
            this.authenticate(jwtRequestModel.getEmail(), jwtRequestModel.getPassword());
            LOGGER.info("Authentication successful for email: {}", jwtRequestModel.getEmail());
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Authentication failed for email: {}", e.getMessage());
            throw new UserException(HttpStatus.NOT_FOUND, UserConstant.EMAIL_NOT_FOUND);
        }
        UserDetails userDetails = this.userDetailsServiceImpl.loadUserByUsername(jwtRequestModel.getEmail());
        String token = this.jwtUtils.generateToken(userDetails);
        LOGGER.info("Login successful for email: {}", jwtRequestModel.getEmail());
        return ResponseEntity.ok( JwtResponseModel.builder().token(token).build());
    }

    /**
     * Authenticates a user with the provided username and password.
     *
     * @param email The username of the user.
     * @param password The password of the user.
     * @throws Exception If authentication fails due to disabled user or invalid credentials.
     */
    private void authenticate(String email, String password) {
        try {
            this.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(email, password));
        } catch (DisabledException e) {
            LOGGER.error("User authentication failed due to DisabledException. Email: {}", e.getMessage());
            throw new UserException(HttpStatus.NOT_FOUND,UserConstant.USER_DISABLED);
        } catch (Exception e) {
            LOGGER.error("User authentication failed due to Exception. Email: {}", e.getMessage());
            throw new UserException(HttpStatus.BAD_REQUEST,UserConstant.INVALID_CREDENTIAL);
        }
  }

}