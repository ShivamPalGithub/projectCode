package com.bridgeInvest.userservice.service.impl;

import com.bridgeInvest.userservice.constant.UserConstant;
import com.bridgeInvest.userservice.exception.UserException;
import com.bridgeInvest.userservice.model.dto.UserModel;
import com.bridgeInvest.userservice.respository.UserRepository;
import com.bridgeInvest.userservice.model.entity.User;
import com.bridgeInvest.userservice.service.UserMapper;
import com.bridgeInvest.userservice.service.UserService;
import com.bridgeInvest.userservice.utils.JwtUtils;
import io.jsonwebtoken.Claims;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

/**
 * Implementation of the UserService interface.
 */
@Service
public class UserServiceImpl implements UserService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);
    private final ThreadPoolTaskExecutor threadPoolTaskExecutor;
    private final UserRepository userRepository;
    BCryptPasswordEncoder bCryptPasswordEncoder;
    private  final JwtUtils jwtUtils;
    private UserMapper userMapper;

    /**
     * Constructs a new UserServiceImpl instance.
     *
     * @param userRepository The UserRepository instance.
     */
    public UserServiceImpl(UserRepository userRepository,
                           @Qualifier("getThreadPoolTaskExecutor") ThreadPoolTaskExecutor threadPoolTaskExecutor, BCryptPasswordEncoder bCryptPasswordEncoder,JwtUtils jwtUtils,UserMapper userMapper) {
        this.userRepository = userRepository;
        this.threadPoolTaskExecutor = threadPoolTaskExecutor;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
        this.jwtUtils=jwtUtils;
        this.userMapper=userMapper;
    }

    /**
     * Retrieves all users.
     *
     * @return A list of User objects representing all users.
     */
    @Override
    //@Async
    public CompletableFuture<List<User>> getAllUser() throws ExecutionException, InterruptedException {
        List<User> userList = userRepository.findAll(); // completableFuture.get(); // Use get() to block and obtain the result
        // Process the userList (if needed)
        return CompletableFuture.completedFuture(userList); // Wrap in another CompletableFuture
    }

    @Async
    public CompletableFuture<List<User>> getAllUsersAsync(String email) {
        //TODO:we are not going to use get() method. Will fix it.
        LOGGER.info("UserServiceImpl -> getAllUsersAsync method called:");
        CompletableFuture<List<User>> completableFuture = userRepository.findAllByEmail(email);
        try {
            List<User> userList = completableFuture.get(); // Use get() to block and obtain the result
            // Process the userList (if needed)
            return CompletableFuture.completedFuture(userList); // Wrap in another CompletableFuture
        } catch (InterruptedException | ExecutionException ex) {
            LOGGER.error("UserServiceImpl -> Exception during asynchronous processing:", ex);
            // Handle exceptions, if any
            // Return an empty list or throw a custom exception as per your requirement
            return CompletableFuture.completedFuture(Collections.emptyList()); // Wrap in another CompletableFuture
        }

    }

    /**
     * Creates a new user.
     *
     * @param user The User object representing the user to be created.
     * @return The created User object.
     */
    @Override
    public CompletableFuture<User> createUser(User user) {
        return this.getUserByEmail(user.getEmail())
                .thenCompose(optionalUser -> {
            if (optionalUser.isPresent()) {
                LOGGER.debug("Username already exists");
                throw new UserException(HttpStatus.CONFLICT, UserConstant.USER_ALREADY_EXIST);
            }
            User newUser = User.builder().
                    email(user.getEmail()).
                    password(this.bCryptPasswordEncoder.encode(user.getPassword())).build();
                   return CompletableFuture.supplyAsync(() -> userRepository.save(newUser))
                           .thenApply(savedUser -> {
                               return savedUser;
                           });
        });
    }

    /**
     * Retrieves a user by name.
     *
     * @param email The name of the user.
     * @return An Optional containing the User object if found, or an empty Optional if not found.
     */
    @Override
    public CompletableFuture<Optional<User>> getUserByEmail(String email) {
        return CompletableFuture.supplyAsync(() -> userRepository.findByEmail(email))
                .thenApply(Optional::ofNullable)
                .thenApply(optionalUser -> optionalUser.orElseThrow(() -> new UserException(HttpStatus.NOT_FOUND, UserConstant.RECORD_NOT_FOUND)));
    }

    /**
     * Finds a user's permissions based on the provided authentication token.
     *
     * @param token The authentication token associated with the user.
     * @return A UserModel representing the user's permissions.
     * @throws UserException If the user is not found or if an error occurs.
     */
    @Override
    public UserModel findUserPermissions(String token){
        Claims claims = jwtUtils.extractAllClaims(token);
        String userId = claims.get("id", String.class);
        User user = userRepository.findById(UUID.fromString(userId)).get();
        if (user != null) {
            return userMapper.userConvertToUserModel(user);

        } else {
            throw new UserException(HttpStatus.BAD_REQUEST, UserConstant.RECORD_NOT_FOUND);
        }
    }
}