package com.bridgeInvest.userservice.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 Represents a JSON Web Token (JWT) response.
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JwtResponseModel {
    private String token;
}
