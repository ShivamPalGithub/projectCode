package com.bridgeInvest.notificationservice.constant;

public class NotificationConstant {

}
