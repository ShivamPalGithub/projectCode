-- Insertion scripts for pre-defined permissions
INSERT INTO permissions (permission_id, permission_name) VALUES ('0dfd0353be2c4102976955c825ad38a5', 'ALL');
INSERT INTO permissions (permission_id, permission_name) VALUES ('f044de8e0f5a4d189de705b1d6d0aca9', 'CREATE');
INSERT INTO permissions (permission_id, permission_name) VALUES ('c88728be29384d078fa6a30161cef99d', 'VIEW');
INSERT INTO permissions (permission_id, permission_name) VALUES ('1adf7412f9894dda985b7f41288d664f', 'UPDATE');
INSERT INTO permissions (permission_id, permission_name) VALUES ('bb144a526b2a4a989b5523a89cabe4fc', 'DELETE');

-- Insertion scripts for pre-defined modules
INSERT INTO modules (module_id, module_name, parent_module_id) VALUES ('7707fa836b9d4a6dbf9293b4a4311eb6', 'CRM', null);
INSERT INTO modules (module_id, module_name, parent_module_id) VALUES ('c9f5bb514f9f4186953dbaa5df32ffc6', 'Brokers', '7707fa836b9d4a6dbf9293b4a4311eb6');
INSERT INTO modules (module_id, module_name, parent_module_id) VALUES ('41fa49db23c145a09af8f10a6773344c', 'Borrowers', '7707fa836b9d4a6dbf9293b4a4311eb6');
INSERT INTO modules (module_id, module_name, parent_module_id) VALUES ('894a4fcfc41547629f032fbcad6674ca', 'Funders', '7707fa836b9d4a6dbf9293b4a4311eb6');
INSERT INTO modules (module_id, module_name, parent_module_id) VALUES ('2be4e326897244349c0812313156b412', 'Valuers', '7707fa836b9d4a6dbf9293b4a4311eb6');
INSERT INTO modules (module_id, module_name, parent_module_id) VALUES ('3987094e916e4fa7996a09c5a73a2a8e', 'Solicitors', '7707fa836b9d4a6dbf9293b4a4311eb6');
INSERT INTO modules (module_id, module_name, parent_module_id) VALUES ('6c707832abc24c4bac747bf879f9a4c9', 'Staff', '7707fa836b9d4a6dbf9293b4a4311eb6');
INSERT INTO modules (module_id, module_name, parent_module_id) VALUES ('21ee13d190704799b7475d927efc8969', 'Referrals', '7707fa836b9d4a6dbf9293b4a4311eb6');
INSERT INTO modules (module_id, module_name, parent_module_id) VALUES ('21d1475ff7d44e8ebad0c106a5ebdcf3', 'Others', '7707fa836b9d4a6dbf9293b4a4311eb6');