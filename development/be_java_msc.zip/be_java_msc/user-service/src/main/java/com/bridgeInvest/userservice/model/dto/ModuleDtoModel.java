package com.bridgeInvest.userservice.model.dto;

import com.bridgeInvest.userservice.model.entity.Module;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Column;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleDtoModel {
    private UUID id;
    private String moduleName;
    @JsonIgnore
    private Module parentModule;
}
