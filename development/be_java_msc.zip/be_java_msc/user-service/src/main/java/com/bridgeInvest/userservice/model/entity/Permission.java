package com.bridgeInvest.userservice.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import java.util.UUID;

@Entity
@Table(name = "permissions")
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Permission {
    @Id
    @Column(name = "permission_id")
    @GeneratedValue
    private UUID id;
    @Column(name = "permission_name")
    private String permissionName;
}
