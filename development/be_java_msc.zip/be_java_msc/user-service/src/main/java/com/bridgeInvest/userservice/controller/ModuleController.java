package com.bridgeInvest.userservice.controller;

import com.bridgeInvest.userservice.model.dto.EntityResponse;
import com.bridgeInvest.userservice.service.ModuleService;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.UUID;

@RestController
@RequestMapping("/api/V1/staff/modules")
public class ModuleController {

    private final ModuleService moduleService;

    public ModuleController(ModuleService moduleService) {
        this.moduleService = moduleService;
    }

    @GetMapping("/fetch-all")
    @ApiResponse(responseCode = "200", description = "Modules fetched successfully")
    public EntityResponse getAllModules() {
        return moduleService.fetchAllModules();
    }

    @GetMapping("/fetch-by-parent/{parent_module_id}")
    public EntityResponse getModulesByParent(@PathVariable("parent_module_id") UUID parentModuleId) {
        return moduleService.findModuleById(parentModuleId);
    }
}
