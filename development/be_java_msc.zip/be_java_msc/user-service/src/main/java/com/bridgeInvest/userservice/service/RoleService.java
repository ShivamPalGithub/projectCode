package com.bridgeInvest.userservice.service;

import com.bridgeInvest.userservice.model.dto.EntityResponse;
import com.bridgeInvest.userservice.model.dto.RolePermissionModel;
import com.bridgeInvest.userservice.model.dto.RoleRequestModel;
import com.bridgeInvest.userservice.model.entity.Role;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RoleService {
    Optional<Role> fetchRoleById(UUID roleId);
    Role saveRole(RoleRequestModel roleRequestModel);
    boolean checkRoleByNameExists(RoleRequestModel roleRequestModel);

    EntityResponse fetchAllRoles();
    Role deleteRoleById(Role role);
    Role updateRoleName(Role role, String name);
    void updateRolePermissions(Role role, List<UUID> moduleIds);

    EntityResponse createRole(RoleRequestModel roleRequestModel);

    EntityResponse assignPermissions(UUID roleId, RolePermissionModel rolePermissionModel);

    EntityResponse deleteRole(UUID roleId);

    EntityResponse updateRoleDetails(UUID roleId, RoleRequestModel roleRequestModel);
}
