package com.bridgeInvest.userservice.constant;

public final class UserConstant {

    public static final String USER_REGISTERED = "User registered successfully";

    public static final String RECORD_NOT_FOUND = "This record is not found";

    public static final String  USER_ALREADY_EXIST = "This username is already exist in database";

    public static final String  EMPTY_FIELDS = "Input fields empty, please look into it";

    public static final String  METHOD_INCORRECT= "Your http method is incorrect";

    public static final String   INVALID_CREDENTIAL = "Invalid credentials";

    public static final String  USER_DISABLED = "User disabled";

}
