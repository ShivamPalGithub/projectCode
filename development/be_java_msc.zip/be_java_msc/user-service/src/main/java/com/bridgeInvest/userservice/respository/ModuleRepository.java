package com.bridgeInvest.userservice.respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.bridgeInvest.userservice.model.entity.Module;
import java.util.List;
import java.util.UUID;

@Repository
public interface ModuleRepository extends JpaRepository<Module, UUID> {

    List<Module> findAllByParentModuleIsNull();

    List<Module> findAllByParentModule(Module parentModule);
}
