package com.bridgeInvest.userservice.service.impl;

import com.bridgeInvest.userservice.model.dto.EntityResponse;
import com.bridgeInvest.userservice.model.dto.PermissionModel;
import com.bridgeInvest.userservice.model.entity.Permission;
import com.bridgeInvest.userservice.respository.PermissionRepository;
import com.bridgeInvest.userservice.service.PermissionService;
import com.bridgeInvest.userservice.utils.ServiceUtil;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import java.util.List;
import java.util.UUID;

@Service
public class PermissionServiceImpl implements PermissionService {

    private final PermissionRepository permissionRepository;
    private final ServiceUtil serviceUtil;
    private final MessageSource messageSource;
    /**
     * Constructs a new PermissionServiceImpl instance.
     *
     * @param permissionRepository The PermissionRepository instance.
     */
    public PermissionServiceImpl(PermissionRepository permissionRepository, ServiceUtil serviceUtil, MessageSource messageSource) {
        this.permissionRepository = permissionRepository;
        this.serviceUtil = serviceUtil;
        this.messageSource = messageSource;
    }

    /**
     * Retrieves all permissions.
     *
     * @return A CompletableFuture representing all permissions.
     */
    @Override
    public EntityResponse fetchAllPermissions() {
        List<Permission> allPermissions = permissionRepository.findAll();
        if(!CollectionUtils.isEmpty(allPermissions)) {
            List<PermissionModel> permissionModelList = serviceUtil.convertPermissionEntityListToModelList(allPermissions);
            return EntityResponse.builder().code(HttpStatus.OK.value()).message(messageSource.getMessage("permissions.fetched.successfully",null, LocaleContextHolder.getLocale())).success(true).data(permissionModelList).build();
        } else {
            return EntityResponse.builder().code(HttpStatus.NOT_FOUND.value()).message(messageSource.getMessage("permissions.not.found",null, LocaleContextHolder.getLocale())).success(false).build();
        }
    }

    /**
     * Retrieves a permission by id.
     *
     * @param id The name of the permission.
     * @return An CompletableFuture containing the Permission object.
     */
    @Override
    public EntityResponse fetchPermissionById(UUID id) {
        Permission permissionById = permissionRepository.findPermissionById(id);
        if(permissionById!=null) {
            PermissionModel permissionModel = serviceUtil.convertPermissionEntityToModel(permissionById);
            return EntityResponse.builder().code(HttpStatus.OK.value()).message(messageSource.getMessage("permission.found.successfully",null, LocaleContextHolder.getLocale())).success(true).data(permissionModel).build();
        } else {
            return EntityResponse.builder().code(HttpStatus.NOT_FOUND.value()).message(messageSource.getMessage("permission.not.found",null, LocaleContextHolder.getLocale())).success(false).build();
        }
    }

}
