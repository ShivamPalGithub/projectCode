package com.bridgeInvest.userservice.utils;

import com.bridgeInvest.userservice.model.dto.ChildModuleResponseModel;
import com.bridgeInvest.userservice.model.dto.ModuleResponseModel;
import com.bridgeInvest.userservice.model.dto.PermissionModel;
import com.bridgeInvest.userservice.model.dto.RoleResponseModel;
import com.bridgeInvest.userservice.model.entity.Permission;
import com.bridgeInvest.userservice.model.entity.Module;
import com.bridgeInvest.userservice.model.entity.Role;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

@Component
public class ServiceUtil {

    public List<PermissionModel> convertPermissionEntityListToModelList(List<Permission> permissions) {
        List<PermissionModel> permissionModelList = new ArrayList<>();
        PermissionModel permissionModel;
        for(Permission permission : permissions) {
            permissionModel = PermissionModel.builder().permissionId(permission.getId()).permissionName(permission.getPermissionName()).build();
            permissionModelList.add(permissionModel);
        }
        return permissionModelList;
    }

    public PermissionModel convertPermissionEntityToModel(Permission permission) {
        return PermissionModel.builder().permissionId(permission.getId()).permissionName(permission.getPermissionName()).build();
    }

    public List<ModuleResponseModel> convertModuleEntityListToModelList(List<Module> modules) {
        List<ModuleResponseModel> moduleResponseModels = new ArrayList<>();
        ModuleResponseModel moduleResponseModel;
        UUID parentId;
        List<ChildModuleResponseModel> childModules;
        Iterator<Module> iterator = modules.iterator();
        while(iterator.hasNext()) {
            Module module = iterator.next();
            if (module.getParentModule() == null) {
                parentId = module.getId();
                childModules = getListOfChildModules(parentId, modules);
                moduleResponseModel = ModuleResponseModel.builder()
                        .moduleId(parentId)
                        .moduleName(module.getModuleName())
                        .childModules(childModules)
                        .build();
                moduleResponseModels.add(moduleResponseModel);
            } else {
                iterator.remove();
            }
        }
        return moduleResponseModels;
    }

    private List<ChildModuleResponseModel> getListOfChildModules(UUID parentId, List<Module> modules) {
        List<ChildModuleResponseModel> moduleResponseModels = new ArrayList<>();
        for(Module module : modules) {
            if(module.getParentModule()!=null && parentId.equals(module.getParentModule().getId())) {
                moduleResponseModels.add(ChildModuleResponseModel.builder().moduleId(module.getId()).moduleName(module.getModuleName()).build());
            }
        }
        return moduleResponseModels;
    }

    public List<RoleResponseModel> convertRoleEntityListToModelList(List<Role> roles) {
        List<RoleResponseModel> roleModelList = new ArrayList<>();
        RoleResponseModel roleResponseModel;
        for(Role role : roles) {
            roleResponseModel = RoleResponseModel.builder().roleId(role.getId()).roleName(role.getName()).build();
            roleModelList.add(roleResponseModel);
        }
        return roleModelList;
    }

}
