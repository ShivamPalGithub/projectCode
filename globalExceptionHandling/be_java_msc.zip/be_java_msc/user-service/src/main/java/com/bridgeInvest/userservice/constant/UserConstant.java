package com.bridgeInvest.userservice.constant;

public final class UserConstant {

    public static final String USER_REGISTERED = "User registered successfully";

    public static final String RECORD_NOT_FOUND = "This record is not found.";

    public static final String  USER_ALREADY_EXIST = "This Username is already exist in database.";

    public static final String  EMPTY_FIELDS = "Input fields are Empty, please look into it.";

    public static final String  METHOD_INCORRECT= "your Http Method is incorrect";

    public static final String   INVALID_CREDENTIAL = " Invalid Credentials ";

    public static final String  USER_DISABLE = " User Disables ";

}
