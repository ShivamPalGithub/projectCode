package com.bridgeInvest.notificationservice.repository;

public interface NotificationRepository {
}
