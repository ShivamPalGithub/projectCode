package com.bridgeinvest.liquibaseservice.constant;

public class LiquibaseConstant {

}
