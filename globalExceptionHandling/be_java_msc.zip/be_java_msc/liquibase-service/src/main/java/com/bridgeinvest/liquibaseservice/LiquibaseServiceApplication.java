package com.bridgeinvest.liquibaseservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiquibaseServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(LiquibaseServiceApplication.class, args);
    }
}