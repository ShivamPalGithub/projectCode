package com.bridgeInvest.loanservice.controller;

public class LoanController {
}
