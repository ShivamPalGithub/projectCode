package com.bridgeInvest.userservice.service;

import com.bridgeInvest.userservice.model.dto.EntityResponse;
import com.bridgeInvest.userservice.model.entity.Module;
import java.util.List;
import java.util.UUID;

public interface ModuleService {
    List<Module> fetchAllModulesWithParentModule(Module parentModule);
    EntityResponse fetchAllModules();
    EntityResponse findModuleById(UUID moduleId);
}
