package com.bridgeInvest.userservice.model.dto;

import com.bridgeInvest.userservice.constant.enums.Status;
import com.bridgeInvest.userservice.model.entity.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RoleModel {

    private UUID id;
    private String systemName;
    private String name;
    private Set<RolePermissionDTOModel> rolePermissions;
    private Status status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private User createdBy;
    private User updatedBy;
}
