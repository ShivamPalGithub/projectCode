package com.bridgeInvest.userservice.model.dto;

import jakarta.persistence.Column;
import jakarta.validation.constraints.Email;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**

 Represents a JSON Web Token (JWT) request.
 */

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JwtRequestModel {
    @Column(unique=true)
    @Email
    private String email;
    private String password;
}
