package com.bridgeInvest.userservice.controller;

import com.bridgeInvest.userservice.constant.UserConstant;
import com.bridgeInvest.userservice.exception.UserException;
import com.bridgeInvest.userservice.model.dto.UserModel;
import com.bridgeInvest.userservice.model.entity.User;
import com.bridgeInvest.userservice.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

/**
 * Controller class for handling user-related endpoints.
 */
@RestController
@RequestMapping("/api/V1/user")
public class UserController {
    private static final Logger LOGGER= LoggerFactory.getLogger(UserController.class);
    private final UserService userService;

    /**
     * Constructs a new UserController with the provided UserService.
     *
     * @param userService The UserService instance.
     */
    public UserController(UserService userService) {
        this.userService = userService;

    }

    /**
     * Retrieves a list of all users.
     *
     * @return A list of User objects.
     */
    @PreAuthorize("hasAnyRole('ADMIN','SUPER-ADMIN')")
    @GetMapping(value = "/getAllUser", produces = "application/json")
    public CompletableFuture<ResponseEntity<List<User>>> getAll() throws ExecutionException, InterruptedException {
        LOGGER.info("UserController -> getAll method called");
        // TODO: Completable future object is not returning the List data.
        CompletableFuture<List<User>> userFuture = userService.getAllUser();
        return userFuture.thenApply(users -> ResponseEntity.ok(users))
                .exceptionally(ex -> ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build());
    }

//    @GetMapping(value = "/getAllUser",  produces = "application/json")
//    //TODO:
//    public CompletableFuture<ResponseEntity<List<User>>> getAll() throws ExecutionException, InterruptedException {
//        //TODO: we are not going to use get() method. Will fix it.
//        LOGGER.info("UserController -> getAll method called");
//       // CompletableFuture<List<User>> completableFuture = userService.getAllUser();
//
//        CompletableFuture<ResponseEntity> completableFuture = userService.getAllUser()
//                .thenApply(ResponseEntity::ok); // completableFuture.get();
//
//        return completableFuture.thenApply(users -> ResponseEntity.ok(users))
//                .exceptionally(ex -> ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build());
//
//     //   return  completableFuture;
//
//    }

    /**
     * Create a new user.
     *
     * @param userDto The user object containing the user information.
     * @return ResponseEntity indicating the result of the operation.
     *         If the username already exists, a bad request response with an error message is returned.
     *         If the user is successfully registered, an OK response is returned.
     */
    @PostMapping("/create")
    public CompletableFuture<ResponseEntity<String>> create(@RequestBody User userDto) {
        //TODO: need to implement the async call working.
        return  userService.createUser(userDto).thenApply(savedUser -> ResponseEntity.ok(UserConstant.USER_REGISTERED));
    }

    /**
     * Retrieves the user's permissions based on the provided authentication token.
     *
     * @param request The authentication token associated with the user.
     * @return A {@link UserModel} representing the user's permissions.
     */
    @GetMapping("/findUserPermissions")
    public UserModel findUserPermissions( HttpServletRequest request){
        String authorizationHeader = request.getHeader("Authorization");
        String jwtToken = null;
        if(authorizationHeader!=null && authorizationHeader.startsWith("Bearer "))
        {
            jwtToken =authorizationHeader.substring(7);
            return  userService.findUserPermissions(jwtToken);
        }
        else {
            LOGGER.info("Invalid Token, not start with Bearer String..!!");
              throw new UserException(HttpStatus.NOT_FOUND,UserConstant.MISSING_AUTHORIZATION_HEADER);
        }
    }

}
