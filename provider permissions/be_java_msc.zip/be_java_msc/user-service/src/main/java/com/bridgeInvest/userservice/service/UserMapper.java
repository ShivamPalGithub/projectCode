package com.bridgeInvest.userservice.service;

import com.bridgeInvest.userservice.model.dto.UserModel;
import com.bridgeInvest.userservice.model.entity.User;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserMapper {
    UserModel userConvertToUserModel(User user);
}
