package com.bridgeInvest.userservice.respository;

import com.bridgeInvest.userservice.model.entity.Permission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.UUID;

@Repository
public interface PermissionRepository extends JpaRepository<Permission, UUID> {

    Permission findPermissionById(UUID id);

    Permission findPermissionByPermissionName(String name);

}
