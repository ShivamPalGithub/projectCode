package com.bridgeInvest.notificationservice.service;

public interface NotificationService {
}
