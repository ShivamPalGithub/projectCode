package com.bridgeInvest.loanservice.constant;

public class LoanConstant {

}
