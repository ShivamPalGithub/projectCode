package com.bridgeInvest.loanservice.controller;
//import io.swagger.annotations.Api;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
@Api(tags="Loan API")
public class LoanController {


    @GetMapping("/hello")
    @ApiOperation("Get a greeting")
    public String hello() {
        return "hello";
    }

   
    @PostMapping(value = "/users", consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Create a new user")
    @RequestBody(content = @Content(schema = @Schema(example = "{\"name\": \"John Doe\", \"email\": \"john.doe@example.com\"}")))
    @ApiResponse(responseCode = "201", description = "User created")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    public void createUser() {
        // Method implementation
    }
}
