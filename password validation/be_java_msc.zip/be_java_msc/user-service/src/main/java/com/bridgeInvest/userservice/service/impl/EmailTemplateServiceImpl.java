package com.bridgeInvest.userservice.service.impl;

import com.bridgeInvest.userservice.model.entity.EmailTemplate;
import com.bridgeInvest.userservice.respository.EmailTemplateRepository;
import com.bridgeInvest.userservice.service.EmailTemplateService;
import org.springframework.stereotype.Service;

@Service
public class EmailTemplateServiceImpl implements EmailTemplateService {

    private final EmailTemplateRepository emailTemplateRepository;

    public EmailTemplateServiceImpl(EmailTemplateRepository emailTemplateRepository) {
        this.emailTemplateRepository = emailTemplateRepository;
    }

    @Override
    public EmailTemplate findTemplateByName(String templateName) {
        return emailTemplateRepository.findEmailTemplateByTemplateName(templateName);
    }

    //TODO: methods to do the operations on email templates
}
