package com.bridgeInvest.userservice.controller;

import com.bridgeInvest.userservice.model.dto.EntityResponse;
import com.bridgeInvest.userservice.model.dto.SetPasswordRequestModel;
import com.bridgeInvest.userservice.service.PasswordService;
import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/V1/")
@Api(tags="Non-login feature APIs")
public class IndexController {
    private static final Logger LOGGER= LoggerFactory.getLogger(IndexController.class);

    private final PasswordService passwordService;

    public IndexController(PasswordService passwordService) {
        this.passwordService = passwordService;
    }

    @GetMapping("/user/set-new-password/{user-token}")
    @ApiResponse(responseCode = "200", description = "Token validated")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @Operation(summary = "API to validate new registration user-token")
    public EntityResponse checkNewRegistrationToken(@PathVariable("user-token") String userToken) {
        return passwordService.validateUserTokenForNewRegistration(userToken);
    }

    @PostMapping("/user/set-new-password/{user-token}")
    @ApiResponse(responseCode = "200", description = "New password set successfully")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @Operation(summary = "API to user-token and set new password")
    public EntityResponse setwPassword(@Valid @RequestBody SetPasswordRequestModel setPasswordRequestModel, @PathVariable("user-token") String userToken) {
        return passwordService.validateUserTokenAndSetNewPasswordForNewRegistration(setPasswordRequestModel,  userToken);
    }

}
