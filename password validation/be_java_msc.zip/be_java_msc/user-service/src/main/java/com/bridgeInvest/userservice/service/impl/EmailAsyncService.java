package com.bridgeInvest.userservice.service.impl;

import com.bridgeInvest.userservice.model.dto.EmailArgs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class EmailAsyncService {
    private static final Logger LOGGER = LoggerFactory.getLogger(EmailAsyncService.class);
    private final WebClient webClient;

    public EmailAsyncService(WebClient webClient) {
        this.webClient = webClient;
    }

    public void sendEmailThroughWebClient(String uri, MediaType mediaType, EmailArgs emailArgs) {
        webClient.post()
                .uri(uri)
                .contentType(mediaType)
                .bodyValue(emailArgs)
                .retrieve()
                .bodyToMono(Void.class)
                .onErrorResume(
                        throwable -> {
                            LOGGER.error("Error sending email: ", throwable.getMessage());
                            return null;
                        }
                )
                .subscribe();
    }

}
