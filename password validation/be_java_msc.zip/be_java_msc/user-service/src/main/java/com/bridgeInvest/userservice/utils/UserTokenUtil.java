package com.bridgeInvest.userservice.utils;

import org.springframework.stereotype.Component;
import java.io.ByteArrayOutputStream;
import java.security.SecureRandom;
import java.util.Base64;

@Component
public class UserTokenUtil {

    public String generateToken() {
        SecureRandom secureRandom = new SecureRandom();
        byte[] randomBytes = new byte[96];
        secureRandom.nextBytes(randomBytes);
        byte[] unwantedCharacters = {'-', '?', '#', '&', '='};
        byte[] filteredRandomBytes = filterUnwantedCharacters(randomBytes, unwantedCharacters);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(filteredRandomBytes);
    }

    private byte[] filterUnwantedCharacters(byte[] inputBytes, byte[] unwantedCharacters) {
        ByteArrayOutputStream filteredBytes = new ByteArrayOutputStream();
        for (byte inputByte : inputBytes) {
            boolean isUnwanted = false;
            for (byte unwantedChar : unwantedCharacters) {
                if (inputByte == unwantedChar) {
                    isUnwanted = true;
                    break;
                }
            }
            if (!isUnwanted) {
                filteredBytes.write(inputByte);
            }
        }
        return filteredBytes.toByteArray();
    }
}
