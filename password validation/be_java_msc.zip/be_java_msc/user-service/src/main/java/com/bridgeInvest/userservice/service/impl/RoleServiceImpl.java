package com.bridgeInvest.userservice.service.impl;

import com.bridgeInvest.userservice.model.dto.EntityResponse;
import com.bridgeInvest.userservice.model.dto.RolePermissionModel;
import com.bridgeInvest.userservice.model.dto.RoleRequestModel;
import com.bridgeInvest.userservice.model.dto.RoleResponseModel;
import com.bridgeInvest.userservice.model.entity.Module;
import com.bridgeInvest.userservice.model.entity.Permission;
import com.bridgeInvest.userservice.model.entity.Role;
import com.bridgeInvest.userservice.model.entity.RolePermission;
import com.bridgeInvest.userservice.respository.ModuleRepository;
import com.bridgeInvest.userservice.respository.PermissionRepository;
import com.bridgeInvest.userservice.respository.RolePermissionRepository;
import com.bridgeInvest.userservice.respository.RoleRepository;
import com.bridgeInvest.userservice.service.RoleService;
import com.bridgeInvest.userservice.utils.ServiceUtil;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class RoleServiceImpl implements RoleService {
    private final RoleRepository roleRepository;
    private final RolePermissionRepository rolePermissionRepository;
    private final PermissionRepository permissionRepository;
    private final ModuleRepository moduleRepository;
    private final ServiceUtil serviceUtil;

    private final MessageSource messageSource;

    public RoleServiceImpl(RoleRepository roleRepository, RolePermissionRepository rolePermissionRepository, PermissionRepository permissionRepository, ModuleRepository moduleRepository, ServiceUtil serviceUtil, MessageSource messageSource) {
        this.roleRepository = roleRepository;
        this.rolePermissionRepository = rolePermissionRepository;
        this.permissionRepository = permissionRepository;
        this.moduleRepository = moduleRepository;
        this.serviceUtil = serviceUtil;
        this.messageSource = messageSource;
    }

    @Override
    public Optional<Role> fetchRoleById(UUID roleId) {
        return roleRepository.findById(roleId);
    }

    @Override
    public Role saveRole(RoleRequestModel roleRequestModel) {
        String roleName = roleRequestModel.getRoleName().trim();
        Role role = new Role(roleName);
        return roleRepository.save(role);
    }

    @Override
    public boolean checkRoleByNameExists(RoleRequestModel roleRequestModel) {
        String formattedRoleName = roleRequestModel.getRoleName().toUpperCase().replace(" ", "_");
        Role existingRole = roleRepository.findRoleBySystemName(formattedRoleName);
        return existingRole != null;
    }

    @Override
    public EntityResponse fetchAllRoles() {
        List<Role> roles = roleRepository.findAll();
        if(!CollectionUtils.isEmpty(roles)) {
            List<RoleResponseModel> roleResponseModels = serviceUtil.convertRoleEntityListToModelList(roles);
            return EntityResponse.builder().code(HttpStatus.OK.value()).message(messageSource.getMessage("roles.fetched.successfully",null, LocaleContextHolder.getLocale())).success(true).data(roleResponseModels).build();
        } else {
            return EntityResponse.builder().code(HttpStatus.NOT_FOUND.value()).message(messageSource.getMessage("roles.not.found",null, LocaleContextHolder.getLocale())).success(false).build();
        }
    }

    @Override
    public Role deleteRoleById(Role role) {
        roleRepository.delete(role);
        return role;
    }

    @Override
    public Role updateRoleName(Role role, String name) {
        Role updatedRole = role.toBuilder().name(name).systemName(name.toUpperCase().replace(" ", "_")).build();
        return roleRepository.save(updatedRole);
    }

    @Override
    public void updateRolePermissions(Role role, List<UUID> moduleIds) {
        List<RolePermission> rolePermissions = rolePermissionRepository.findAllByRole(role);
        Permission permission = permissionRepository.findPermissionByPermissionName("ALL");
        if(!CollectionUtils.isEmpty(rolePermissions)) {
            rolePermissionRepository.deleteAllByRole(role);
        }
        for (UUID moduleId : moduleIds) {
            Optional<Module> moduleById = moduleRepository.findById(moduleId);
            if(moduleById.isPresent()) {
                RolePermission rolePermission = RolePermission.builder().permission(permission).role(role).module(moduleById.get()).updatedAt(LocalDateTime.now()).build();
                rolePermissionRepository.save(rolePermission);
            }
        }
    }

    @Override
    public EntityResponse createRole(RoleRequestModel roleRequestModel) {
        if(roleRequestModel!=null && roleRequestModel.getRoleName()!=null && !roleRequestModel.getRoleName().trim().isEmpty()) {
            if (!checkRoleByNameExists(roleRequestModel)) {
                Role role = saveRole(roleRequestModel);
                RoleResponseModel roleResponseModel = RoleResponseModel.builder().roleId(role.getId()).roleName(role.getName()).build();
                return EntityResponse.builder().code(HttpStatus.CREATED.value()).message(messageSource.getMessage("role.created.successfully",null, LocaleContextHolder.getLocale())).success(true).data(roleResponseModel).build();
            } else {
                return EntityResponse.builder().code(HttpStatus.BAD_REQUEST.value()).message(messageSource.getMessage("role.already.exists",null, LocaleContextHolder.getLocale())).success(false).data(roleRequestModel).build();
            }
        } else {
            return EntityResponse.builder().code(HttpStatus.BAD_REQUEST.value()).message(messageSource.getMessage("role.name.not.empty",null, LocaleContextHolder.getLocale())).success(false).build();
        }
    }

    @Override
    public EntityResponse assignPermissions(UUID roleId, RolePermissionModel rolePermissionModel) {
        Optional<Role> role = fetchRoleById(roleId);
        if(role.isPresent()) {
            updateRolePermissions(role.get(), rolePermissionModel.getModulePermissionList());
            return EntityResponse.builder().code(HttpStatus.OK.value()).message(messageSource.getMessage("role.permissions.assigned",null, LocaleContextHolder.getLocale())).success(true).build();
        } else {
            return EntityResponse.builder().code(HttpStatus.BAD_REQUEST.value()).message(messageSource.getMessage("roles.not.found",null, LocaleContextHolder.getLocale())).success(false).build();
        }
    }

    @Override
    public EntityResponse deleteRole(UUID roleId) {
        Optional<Role> role = fetchRoleById(roleId);
        //TODO: if role found, check if no staff is associated with that role, if not then delete (pending)
        if(role.isPresent()) {
            deleteRoleById(role.get());
            return EntityResponse.builder().code(HttpStatus.NO_CONTENT.value()).message(messageSource.getMessage("role.deleted.successfully",null, LocaleContextHolder.getLocale())).success(true).build();
        } else {
            return EntityResponse.builder().code(HttpStatus.BAD_REQUEST.value()).message(messageSource.getMessage("roles.not.found",null, LocaleContextHolder.getLocale())).success(false).build();
        }
    }

    @Override
    public EntityResponse updateRoleDetails(UUID roleId, RoleRequestModel roleRequestModel) {
        if(roleRequestModel!=null && roleRequestModel.getRoleName()!=null && !roleRequestModel.getRoleName().trim().isEmpty()) {
            Optional<Role> role = fetchRoleById(roleId);
            if (role.isPresent()) {
                if(!checkRoleByNameExists(roleRequestModel)) {
                    updateRoleName(role.get(), roleRequestModel.getRoleName());
                    return EntityResponse.builder().code(HttpStatus.OK.value()).message(messageSource.getMessage("role.updated.successfully",null, LocaleContextHolder.getLocale())).success(true).build();
                } else {
                    return EntityResponse.builder().code(HttpStatus.BAD_REQUEST.value()).message(messageSource.getMessage("role.already.exists",null, LocaleContextHolder.getLocale())).success(false).data(roleRequestModel).build();
                }
            } else {
                return EntityResponse.builder().code(HttpStatus.NOT_FOUND.value()).message(messageSource.getMessage("roles.not.found",null, LocaleContextHolder.getLocale())).success(false).build();
            }
        } else {
            return EntityResponse.builder().code(HttpStatus.BAD_REQUEST.value()).message(messageSource.getMessage("role.name.not.empty",null, LocaleContextHolder.getLocale())).success(false).build();
        }
    }

}
