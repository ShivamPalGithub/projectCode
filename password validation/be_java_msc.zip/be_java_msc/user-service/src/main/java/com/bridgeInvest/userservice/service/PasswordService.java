package com.bridgeInvest.userservice.service;

import com.bridgeInvest.userservice.model.dto.EntityResponse;
import com.bridgeInvest.userservice.model.dto.SetPasswordRequestModel;

public interface PasswordService {

    EntityResponse validateUserTokenForNewRegistration(String userToken);

    EntityResponse validateUserTokenAndSetNewPasswordForNewRegistration(SetPasswordRequestModel setPasswordRequestModel,  String userToken);
}
