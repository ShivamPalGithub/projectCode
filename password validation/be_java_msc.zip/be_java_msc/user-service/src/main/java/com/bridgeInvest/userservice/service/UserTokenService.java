package com.bridgeInvest.userservice.service;

import com.bridgeInvest.userservice.constant.enums.TokenType;
import com.bridgeInvest.userservice.model.entity.User;
import com.bridgeInvest.userservice.model.entity.UserToken;

public interface UserTokenService {

    UserToken generateUniqueToken(User user, TokenType tokenType);

    boolean isTokenExpired(String token, TokenType tokenType);

    boolean isTokenValid(String token, TokenType tokenType);

    UserToken saveUserToken(UserToken userToken);
}
