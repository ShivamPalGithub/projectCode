package com.bridgeInvest.userservice.service.impl;

import com.bridgeInvest.userservice.constant.UserConstant;
import com.bridgeInvest.userservice.exception.UserException;
import com.bridgeInvest.userservice.respository.UserRepository;
import com.bridgeInvest.userservice.model.entity.User;
import com.bridgeInvest.userservice.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;

import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;


/**
 * Implementation of the UserService interface.
 */
@Service
public class UserServiceImpl implements UserService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

    private final ThreadPoolTaskExecutor threadPoolTaskExecutor;

    private final UserRepository userRepository;

    BCryptPasswordEncoder bCryptPasswordEncoder;

    /**
     * Constructs a new UserServiceImpl instance.
     *
     * @param userRepository The UserRepository instance.
     */
    public UserServiceImpl(UserRepository userRepository,
                           @Qualifier("getThreadPoolTaskExecutor") ThreadPoolTaskExecutor threadPoolTaskExecutor, BCryptPasswordEncoder bCryptPasswordEncoder) {
        this.userRepository = userRepository;
        this.threadPoolTaskExecutor = threadPoolTaskExecutor;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }

    /**
     * Retrieves all users.
     *
     * @return A list of User objects representing all users.
     */
    @Override
    //@Async
    public CompletableFuture<List<User>> getAllUser() throws ExecutionException, InterruptedException {
        List<User> userList = userRepository.findAll(); // completableFuture.get(); // Use get() to block and obtain the result
        // Process the userList (if needed)
        return CompletableFuture.completedFuture(userList); // Wrap in another CompletableFuture
    }

    @Async
    public CompletableFuture<List<User>> getAllUsersAsync(String name) {
        //TODO:we are not going to use get() method. Will fix it.
        LOGGER.info("UserServiceImpl -> getAllUsersAsync method called:");
        CompletableFuture<List<User>> completableFuture = userRepository.findAllByName(name);
        try {
            List<User> userList = completableFuture.get(); // Use get() to block and obtain the result
            // Process the userList (if needed)
            return CompletableFuture.completedFuture(userList); // Wrap in another CompletableFuture
        } catch (InterruptedException | ExecutionException ex) {
            LOGGER.error("UserServiceImpl -> Exception during asynchronous processing:", ex);
            // Handle exceptions, if any
            // Return an empty list or throw a custom exception as per your requirement
            return CompletableFuture.completedFuture(Collections.emptyList()); // Wrap in another CompletableFuture
        }

    }

    /**
     * Creates a new user.
     *
     * @param user The User object representing the user to be created.
     * @return The created User object.
     */
    @Override
    public CompletableFuture<User> createUser(User user) {
        return this.getUserByName(user.getName())
                .thenCompose(optionalUser -> {
            if (optionalUser.isPresent()) {
                LOGGER.debug("Username already exists");
                throw new UserException(HttpStatus.CONFLICT, UserConstant.USER_ALREADY_EXIST);
            }
            User newUser = User.builder().
                    name(user.getName()).
                    password(this.bCryptPasswordEncoder.encode(user.getPassword())).build();
                   return CompletableFuture.supplyAsync(() -> userRepository.save(newUser))
                           .thenApply(savedUser -> {
                               return savedUser;
                           });
        });
    }

    /**
     * Retrieves a user by name.
     *
     * @param name The name of the user.
     * @return An Optional containing the User object if found, or an empty Optional if not found.
     */
    @Override
    public CompletableFuture<Optional<User>> getUserByName(String name) {
        return CompletableFuture.supplyAsync(() -> userRepository.findByName(name))
                .thenApply(Optional::ofNullable)
                .thenApply(optionalUser -> optionalUser.orElseThrow(() -> new UserException(HttpStatus.NOT_FOUND, UserConstant.RECORD_NOT_FOUND)));
    }
}