package com.bridgeInvest.userservice.respository;

import com.bridgeInvest.userservice.model.entity.EmailTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.UUID;

@Repository
public interface EmailTemplateRepository extends JpaRepository<EmailTemplate, UUID> {

    EmailTemplate findEmailTemplateByTemplateName(String templateName);
}
