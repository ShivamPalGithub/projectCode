package com.bridgeInvest.userservice.service.impl;

import com.bridgeInvest.userservice.constant.enums.Status;
import com.bridgeInvest.userservice.constant.enums.TokenFailure;
import com.bridgeInvest.userservice.constant.enums.TokenType;
import com.bridgeInvest.userservice.model.dto.EntityResponse;
import com.bridgeInvest.userservice.model.dto.SetPasswordRequestModel;
import com.bridgeInvest.userservice.model.entity.User;
import com.bridgeInvest.userservice.model.entity.UserToken;
import com.bridgeInvest.userservice.respository.UserRepository;
import com.bridgeInvest.userservice.respository.UserTokenRepository;
import com.bridgeInvest.userservice.service.PasswordService;
import com.google.common.util.concurrent.RateLimiter;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class PasswordServiceImpl implements PasswordService {
    private static final Logger LOGGER= LoggerFactory.getLogger(PasswordServiceImpl.class);
    private final UserTokenRepository userTokenRepository;
    private final MessageSource messageSource;
    private final RateLimiter rateLimiter;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;
    private final UserRepository userRepository;

    public PasswordServiceImpl(UserTokenRepository userTokenRepository, MessageSource messageSource, RateLimiter rateLimiter, BCryptPasswordEncoder bCryptPasswordEncoder, UserRepository userRepository) {
        this.userTokenRepository = userTokenRepository;
        this.messageSource = messageSource;
        this.rateLimiter = rateLimiter;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
        this.userRepository = userRepository;
    }

    @Override
    public EntityResponse validateUserTokenForNewRegistration(String userToken) {
        if (rateLimiter.tryAcquire()) {
            if(StringUtils.isNotEmpty(userToken)) {
                if (userTokenRepository.existsUserTokenByTokenAndTokenType(userToken, TokenType.NEW_REGISTRATION)) {
                    UserToken userToken1 = userTokenRepository.findUserTokenByTokenAndTokenType(userToken, TokenType.NEW_REGISTRATION);
                    if (userToken1.getStatus().equals(Status.ACTIVE)) {
                        if (!userToken1.isTokenExpired()) {
                            return EntityResponse.builder().success(true).code(HttpStatus.OK.value()).message(messageSource.getMessage("new.registration.token.valid", null, LocaleContextHolder.getLocale())).build();
                        } else {
                            return EntityResponse.builder().success(false).code(HttpStatus.BAD_REQUEST.value()).data(TokenFailure.TOKEN_EXPIRED).message(messageSource.getMessage("new.registration.token.expired", null, LocaleContextHolder.getLocale())).build();
                        }
                    } else {
                        return EntityResponse.builder().success(false).code(HttpStatus.BAD_REQUEST.value()).data(TokenFailure.TOKEN_INVALID).message(messageSource.getMessage("new.registration.token.invalid", null, LocaleContextHolder.getLocale())).build();
                    }
                } else {
                    return EntityResponse.builder().success(false).code(HttpStatus.BAD_REQUEST.value()).data(TokenFailure.TOKEN_INVALID).message(messageSource.getMessage("new.registration.token.invalid", null, LocaleContextHolder.getLocale())).build();
                }
            } else {
                return EntityResponse.builder().success(false).code(HttpStatus.BAD_REQUEST.value()).data(TokenFailure.TOKEN_MISSING).message(messageSource.getMessage("new.registration.token.invalid", null, LocaleContextHolder.getLocale())).build();
            }
        } else {
            return EntityResponse.builder().success(false).code(HttpStatus.TOO_MANY_REQUESTS.value()).message(messageSource.getMessage("too.many.requests", null, LocaleContextHolder.getLocale())).build();
        }
    }

    @Override
    public EntityResponse validateUserTokenAndSetNewPasswordForNewRegistration(SetPasswordRequestModel setPasswordRequestModel, String userToken) {
        if (rateLimiter.tryAcquire()) {
            if(StringUtils.isNotEmpty(userToken)) {
                if (userTokenRepository.existsUserTokenByTokenAndTokenType(userToken, TokenType.NEW_REGISTRATION)) {
                    UserToken userToken1 = userTokenRepository.findUserTokenByTokenAndTokenType(userToken, TokenType.NEW_REGISTRATION);
                    if (userToken1.getStatus().equals(Status.ACTIVE)) {
                        if (!userToken1.isTokenExpired()) {
                            User user = userToken1.getUser();
                            updatePassword(setPasswordRequestModel, user);
                            disableUserToken(userToken1);
                            LOGGER.info("Password successfully updated for the user: {}", user.getName());
                            return EntityResponse.builder().success(true).code(HttpStatus.OK.value()).message(messageSource.getMessage("new.registration.password.set.successfully", null, LocaleContextHolder.getLocale())).build();
                        } else {
                            return EntityResponse.builder().success(false).code(HttpStatus.BAD_REQUEST.value()).data(TokenFailure.TOKEN_EXPIRED).message(messageSource.getMessage("new.registration.token.expired", null, LocaleContextHolder.getLocale())).build();
                        }
                    } else {
                        return EntityResponse.builder().success(false).code(HttpStatus.BAD_REQUEST.value()).data(TokenFailure.TOKEN_INVALID).message(messageSource.getMessage("new.registration.token.invalid", null, LocaleContextHolder.getLocale())).build();
                    }
                } else {
                    return EntityResponse.builder().success(false).code(HttpStatus.BAD_REQUEST.value()).data(TokenFailure.TOKEN_INVALID).message(messageSource.getMessage("new.registration.token.invalid", null, LocaleContextHolder.getLocale())).build();
                }
            } else {
                return EntityResponse.builder().success(false).code(HttpStatus.BAD_REQUEST.value()).data(TokenFailure.TOKEN_MISSING).message(messageSource.getMessage("new.registration.token.invalid", null, LocaleContextHolder.getLocale())).build();
            }
        } else {
            return EntityResponse.builder().success(false).code(HttpStatus.TOO_MANY_REQUESTS.value()).message(messageSource.getMessage("too.many.requests", null, LocaleContextHolder.getLocale())).build();
        }
    }

    private void updatePassword(SetPasswordRequestModel setPasswordRequestModel, User user) {
        String encodedPassword = bCryptPasswordEncoder.encode(setPasswordRequestModel.getNewPassword());
        user = user.toBuilder().password(encodedPassword).status(Status.ACTIVE).build();
        userRepository.save(user);
    }

    private void disableUserToken(UserToken userToken1) {
        userToken1 = userToken1.toBuilder().status(Status.INACTIVE).build();
        userTokenRepository.save(userToken1);
    }

}
