package com.bridgeInvest.userservice.model.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class SetPasswordRequestModel {

    @NotBlank(message = "Password cannot be empty.")
    @Pattern.List({
            @Pattern(regexp = ".*[A-Z].*", message = "Password must contain at least one uppercase letter."),
            @Pattern(regexp = ".*[a-z].*", message = "Password must contain at least one lowercase letter."),
            @Pattern(regexp = ".*\\d.*", message = "Password must contain at least one digit."),
            @Pattern(regexp = ".*[\\W].*", message = "Password must contain at least one special character."),
            @Pattern(regexp = "^[\\S]{8,50}$", message = "Password must be between 8 and 50 characters and contain no spaces.")
    })
    private String newPassword;
}
