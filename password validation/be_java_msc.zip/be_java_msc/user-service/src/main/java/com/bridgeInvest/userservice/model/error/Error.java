package com.bridgeInvest.userservice.model.error;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;
import com.bridgeInvest.userservice.constant.enums.ErrorType;
import lombok.Builder;
import lombok.Data;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;

@Data
@Builder
public class Error {
    private boolean success;
    private int code;
    private String message;
    private List<ErrorDetail> details;

    @Data
    @Builder
    @JsonInclude(NON_EMPTY)
    public static class ErrorDetail {
        private ErrorType type;
        private String field;
        private String message;
    }
}
