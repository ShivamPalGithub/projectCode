package com.bridgeInvest.userservice.model.dto;

import lombok.Builder;
import lombok.Getter;
import java.util.List;

//TODO: this class will be moved to the common library
@Builder
@Getter
public class EmailArgs {
    private List<String> toRecipients;
    private List<String> ccRecipients;
    private List<String> bccRecipients;
    private String subject;
    private List<String> attachments;
    private List<Object> arguments;
    private String content;
}
