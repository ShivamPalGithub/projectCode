package com.bridgeInvest.userservice.service.impl;

import com.bridgeInvest.userservice.constant.enums.Status;
import com.bridgeInvest.userservice.constant.enums.TokenType;
import com.bridgeInvest.userservice.model.entity.User;
import com.bridgeInvest.userservice.model.entity.UserToken;
import com.bridgeInvest.userservice.respository.UserTokenRepository;
import com.bridgeInvest.userservice.service.UserTokenService;
import com.bridgeInvest.userservice.utils.UserTokenUtil;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class UserTokenServiceImpl implements UserTokenService {

    private final UserTokenRepository userTokenRepository;
    private final UserTokenUtil userTokenUtil;

    public UserTokenServiceImpl(UserTokenRepository userTokenRepository, UserTokenUtil userTokenUtil) {
        this.userTokenRepository = userTokenRepository;
        this.userTokenUtil = userTokenUtil;
    }

    @Override
    public UserToken generateUniqueToken(User user, TokenType tokenType) {
        while(true) {
            String generatedToken = userTokenUtil.generateToken();
            if (!userTokenRepository.existsUserTokenByTokenAndTokenType(generatedToken, tokenType)) {
                return UserToken.builder()
                        .token(generatedToken).user(user)
                        .tokenType(tokenType).tokenExpiryDateTime(LocalDateTime.now().plusHours(24))
                        .status(Status.ACTIVE).build();
            }
        }
    }

    @Override
    public boolean isTokenExpired(String token, TokenType tokenType) {
        if(userTokenRepository.existsUserTokenByTokenAndTokenType(token, tokenType)) {
            return userTokenRepository.findUserTokenByTokenAndTokenType(token, tokenType)
                    .getTokenExpiryDateTime().isAfter(LocalDateTime.now());
        }
        return false;
    }

    @Override
    public boolean isTokenValid(String token, TokenType tokenType) {
        return userTokenRepository.findUserTokenByTokenAndTokenType(token, tokenType) != null;
    }

    @Override
    public UserToken saveUserToken(UserToken userToken) {
        return userTokenRepository.save(userToken);
    }

}
