package com.bridgeInvest.userservice.config;

import com.google.common.util.concurrent.RateLimiter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RateLimitingConfig {

    private static final double REQUESTS_PER_SECOND = 5.0;

    @Bean
    public RateLimiter rateLimiter() {
        return RateLimiter.create(REQUESTS_PER_SECOND);
    }
}
