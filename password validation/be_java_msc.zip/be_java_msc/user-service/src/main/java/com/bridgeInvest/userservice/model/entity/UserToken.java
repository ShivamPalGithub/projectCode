package com.bridgeInvest.userservice.model.entity;

import com.bridgeInvest.userservice.constant.enums.TokenType;
import com.bridgeInvest.userservice.model.dto.BaseEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name="user_tokens")
@Getter
@SuperBuilder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class UserToken extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;
    private String token;
    @Enumerated(EnumType.STRING)
    private TokenType tokenType;
    private LocalDateTime tokenExpiryDateTime;
    @ManyToOne
    @JoinColumn(name = "user_id_fk")
    private User user;

    public boolean isTokenExpired() {
        return this.tokenExpiryDateTime.isBefore(LocalDateTime.now());
    }
}
