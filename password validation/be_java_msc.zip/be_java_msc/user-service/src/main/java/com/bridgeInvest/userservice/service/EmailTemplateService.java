package com.bridgeInvest.userservice.service;

import com.bridgeInvest.userservice.model.entity.EmailTemplate;

public interface EmailTemplateService {

    EmailTemplate findTemplateByName(String templateName);
}
