package com.bridgeInvest.userservice.service.impl;

import com.bridgeInvest.userservice.model.dto.EntityResponse;
import com.bridgeInvest.userservice.model.dto.ModuleResponseModel;
import com.bridgeInvest.userservice.model.entity.Module;
import com.bridgeInvest.userservice.respository.ModuleRepository;
import com.bridgeInvest.userservice.service.ModuleService;
import com.bridgeInvest.userservice.utils.ServiceUtil;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ModuleServiceImpl implements ModuleService {

    private final ModuleRepository moduleRepository;

    private final ServiceUtil serviceUtil;
    private final MessageSource messageSource;

    public ModuleServiceImpl(ModuleRepository moduleRepository, ServiceUtil serviceUtil, MessageSource messageSource) {
        this.moduleRepository = moduleRepository;
        this.serviceUtil = serviceUtil;
        this.messageSource = messageSource;
    }

    @Override
    public List<Module> fetchAllModulesWithParentModule(Module parentModule) {
        return moduleRepository.findAllByParentModule(parentModule);
    }

    @Override
    public EntityResponse fetchAllModules() {
        List<Module> allModules = moduleRepository.findAll();
        if(!CollectionUtils.isEmpty(allModules)) {
            List<ModuleResponseModel> moduleResponseModels = serviceUtil.convertModuleEntityListToModelList(allModules);
            return EntityResponse.builder().code(HttpStatus.OK.value()).message(messageSource.getMessage("modules.fetched.successfully",null, LocaleContextHolder.getLocale())).success(true).data(moduleResponseModels).build();
        } else {
            return EntityResponse.builder().code(HttpStatus.NOT_FOUND.value()).message(messageSource.getMessage("modules.not.found",null, LocaleContextHolder.getLocale())).success(false).build();
        }
    }

    @Override
    public EntityResponse findModuleById(UUID moduleId) {
        Optional<Module> parentModule = moduleRepository.findById(moduleId);
        if(parentModule.isPresent()) {
            List<Module> modulesByParent = fetchAllModulesWithParentModule(parentModule.get());
            List<ModuleResponseModel> moduleResponseModels = serviceUtil.convertModuleEntityListToModelList(modulesByParent);
            return EntityResponse.builder().code(HttpStatus.OK.value()).message(messageSource.getMessage("modules.fetched.successfully",null, LocaleContextHolder.getLocale())).success(true).data(moduleResponseModels).build();
        } else {
            return EntityResponse.builder().code(HttpStatus.NOT_FOUND.value()).message(messageSource.getMessage("modules.parent.not.present",null, LocaleContextHolder.getLocale())).success(false).build();
        }
    }
}
