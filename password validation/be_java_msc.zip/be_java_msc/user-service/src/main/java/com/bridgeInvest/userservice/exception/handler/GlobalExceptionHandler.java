package com.bridgeInvest.userservice.exception.handler;

import com.bridgeInvest.userservice.constant.UserConstant;
import com.bridgeInvest.userservice.constant.enums.ErrorType;
import com.bridgeInvest.userservice.exception.UserException;
import com.bridgeInvest.userservice.model.error.Error;
import io.jsonwebtoken.io.IOException;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.time.DateTimeException;
import java.util.List;
import java.util.stream.Stream;
import static org.springframework.core.Ordered.HIGHEST_PRECEDENCE;


@Order(value = HIGHEST_PRECEDENCE)
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        final Stream<Error.ErrorDetail> fieldErrorStream = getStreamOfErrorDetail(ex.getBindingResult().getFieldErrors(), ErrorType.INVALID_FIELD);
        final Stream<Error.ErrorDetail> globalErrorStream = getStreamOfErrorDetail(ex.getBindingResult().getGlobalErrors(), ErrorType.INVALID_DATA);
        final Error error = getApiErrorResponse(Stream.concat(fieldErrorStream, globalErrorStream).toList());
        return new ResponseEntity<>(error, status);
    }

    private Stream<Error.ErrorDetail> getStreamOfErrorDetail(final List<? extends ObjectError> objectErrors,
                                                             final ErrorType errorType) {
        return objectErrors.stream().map(objectError -> {
            if (objectError instanceof FieldError fieldError) {
                return getFieldErrorDetail(fieldError, errorType);
            } else {
                return getObjectErrorDetail(objectError, errorType);
            }
        });
    }

    private Error.ErrorDetail getObjectErrorDetail(ObjectError objectError, ErrorType errorType) {
        return Error.ErrorDetail.builder().message(objectError.getDefaultMessage()).type(errorType).build();
    }

    private Error.ErrorDetail getFieldErrorDetail(FieldError fieldError, ErrorType errorType) {
        return Error.ErrorDetail.builder().field(fieldError.getField()).message(fieldError.getDefaultMessage()).type(errorType).build();
    }

    private Error getApiErrorResponse(final List<Error.ErrorDetail> errorDetails) {
        return Error.builder().success(false).code(HttpStatus.BAD_REQUEST.value()).message(HttpStatus.BAD_REQUEST.name()).details(errorDetails).build();
    }

    @ExceptionHandler(value = UserException.class)
    public ResponseEntity<String> handleUserException(UserException userException) {
        return new ResponseEntity<String>(userException.getErrorMessage(),userException.getErrorCode());
    }
    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        return new ResponseEntity<Object>(UserConstant.METHOD_INCORRECT, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = SQLException.class)
    protected ResponseEntity<Object> handleSQLException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = NullPointerException.class)
    protected ResponseEntity<Object> handleNullPointerException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = IOException.class)
    protected ResponseEntity<Object> handleIOException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = IllegalArgumentException.class)
    protected ResponseEntity<Object> handleIllegalArgumentException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = ArrayIndexOutOfBoundsException.class)
    protected ResponseEntity<Object> handleArrayIndexOutOfBoundsException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = FileNotFoundException.class)
    protected ResponseEntity<Object> handleFileNotFoundException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = DateTimeException.class)
    protected ResponseEntity<Object> handleDateTimeException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = EnumConstantNotPresentException.class)
    protected ResponseEntity<Object> handleEnumConstantNotPresentException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

}
