package com.bridgeInvest.userservice.constant.enums;

public enum TokenType {
    NEW_REGISTRATION(0),
    FORGOT_PASSWORD(1);

    int tokenTypeValue;

    TokenType(int i) {
        tokenTypeValue = i;
    }

}
