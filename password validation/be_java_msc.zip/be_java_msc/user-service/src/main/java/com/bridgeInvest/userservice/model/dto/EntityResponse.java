package com.bridgeInvest.userservice.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class EntityResponse<T, M> {

    private boolean success;
    private int code;
    private T data;
    private String message;
    private M metaData;

}
