package com.bridgeInvest.userservice.respository;

import com.bridgeInvest.userservice.constant.enums.TokenType;
import com.bridgeInvest.userservice.model.entity.UserToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.UUID;

@Repository
public interface UserTokenRepository extends JpaRepository<UserToken, UUID> {

    boolean existsUserTokenByTokenAndTokenType(String token, TokenType tokenType);

    UserToken findUserTokenByTokenAndTokenType(String token, TokenType tokenType);

}
