package com.bridgeInvest.userservice.constant.enums;

public enum TokenFailure {

    TOKEN_INVALID,
    TOKEN_EXPIRED,
    TOKEN_MISSING
}
