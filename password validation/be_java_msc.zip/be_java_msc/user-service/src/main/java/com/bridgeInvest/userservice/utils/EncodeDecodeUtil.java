package com.bridgeInvest.userservice.utils;

import org.springframework.stereotype.Component;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Component
public class EncodeDecodeUtil {

    public String encodeData(String data) {
        return Base64.getEncoder().encodeToString(data.getBytes(StandardCharsets.UTF_8));
    }

    public String decodeData(String data) {
        return new java.lang.String(Base64.getDecoder().decode(data), StandardCharsets.UTF_8);
    }

}
