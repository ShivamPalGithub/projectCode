package com.bridgeInvest.userservice.controller;

import com.bridgeInvest.userservice.model.dto.EntityResponse;
import com.bridgeInvest.userservice.model.dto.RolePermissionModel;
import com.bridgeInvest.userservice.model.dto.RoleRequestModel;
import com.bridgeInvest.userservice.service.RoleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
@RequestMapping(value = "/api/V1/staff")
public class RoleController {

    private final RoleService roleService;

    public RoleController(RoleService roleService) {
        this.roleService = roleService;
    }

    @PostMapping("/create-role")
    @ApiResponse(responseCode = "201", description = "User created")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @Operation(summary = "Add new role")
    public EntityResponse create(@RequestBody RoleRequestModel roleRequestModel) {
        return roleService.createRole(roleRequestModel);
    }

    @GetMapping("/get-roles")
    @ApiResponse(responseCode = "200", description = "Roles fetched successfully")
    @ApiResponse(responseCode = "404", description = "No roles found")
    @Operation(summary = "Fetch all roles")
    public EntityResponse fetchAll() {
        return roleService.fetchAllRoles();
    }

    @DeleteMapping("/delete-role/{roleId}")
    @ApiResponse(responseCode = "204", description = "Role deleted successfully")
    @ApiResponse(responseCode = "400", description = "No role found")
    @ApiResponse(responseCode = "403", description = "Role has associated staff members")
    @Operation(summary = "Delete a role")
    public EntityResponse delete(@PathVariable("roleId") UUID roleId) {
        return roleService.deleteRole(roleId);
    }

    @PostMapping("/assign/permissions/{roleId}")
    @ApiResponse(responseCode = "200", description = "Permissions updated successfully")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @Operation(summary = "Assigning permissions to a Role")
    public EntityResponse assignPermissions(@PathVariable("roleId") UUID roleId, @RequestBody RolePermissionModel rolePermissionModel) {
        return roleService.assignPermissions(roleId, rolePermissionModel);
    }

    @PutMapping("/update-role/{roleId}")
    @ApiResponse(responseCode = "200", description = "Role updated successfully")
    @ApiResponse(responseCode = "404", description = "No roles found")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @Operation(summary = "Updating name for a Role")
    public EntityResponse updateRoleDetails(@PathVariable("roleId") UUID roleId, @RequestBody RoleRequestModel roleRequestModel) {
        return roleService.updateRoleDetails(roleId, roleRequestModel);
    }

}
