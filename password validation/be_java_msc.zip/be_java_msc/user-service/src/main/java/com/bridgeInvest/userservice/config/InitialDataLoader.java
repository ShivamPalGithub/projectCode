package com.bridgeInvest.userservice.config;

import com.bridgeInvest.userservice.constant.enums.Status;
import com.bridgeInvest.userservice.constant.enums.TokenType;
import com.bridgeInvest.userservice.model.dto.EmailArgs;
import com.bridgeInvest.userservice.model.entity.Module;
import com.bridgeInvest.userservice.model.entity.*;
import com.bridgeInvest.userservice.respository.*;
import com.bridgeInvest.userservice.service.EmailTemplateService;
import com.bridgeInvest.userservice.service.UserTokenService;
import com.bridgeInvest.userservice.service.impl.EmailAsyncService;
import com.bridgeInvest.userservice.utils.EncodeDecodeUtil;
import com.bridgeInvest.userservice.utils.ServiceUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import java.util.*;
import static java.util.Map.entry;

@Component
public class InitialDataLoader implements CommandLineRunner {

    private static final Logger LOGGER = LoggerFactory.getLogger(InitialDataLoader.class);
    @Value("${send.email.api.path}") private String sendEmailApiPath;
    @Value("${base.url}") private String baseUrl;
    @Value("${server.servlet.context-path}") private String contextPath;
    private static final String ADMIN_ROLE = "SUPER_ADMIN";
    private static final String NEW_REGISTRATION_EMAIL_TEMPLATE_NAME = "SET_PASSWORD_NEW_REGISTRATION";
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final RolePermissionRepository rolePermissionRepository;
    private final UserRoleRepository userRoleRepository;
    private final ModuleRepository moduleRepository;
    private final PermissionRepository permissionRepository;
    private final UserTokenService userTokenService;
    private final EmailAsyncService emailAsyncService;
    private final EmailTemplateService emailTemplateService;
    private final ServiceUtil serviceUtil;
    private final EncodeDecodeUtil encodeDecodeUtil;

    public InitialDataLoader(UserRepository userRepository, RoleRepository roleRepository, RolePermissionRepository rolePermissionRepository, UserRoleRepository userRoleRepository, ModuleRepository moduleRepository, PermissionRepository permissionRepository, UserTokenService userTokenService, EmailAsyncService emailAsyncService, EmailTemplateService emailTemplateService, ServiceUtil serviceUtil, EncodeDecodeUtil encodeDecodeUtil) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.rolePermissionRepository = rolePermissionRepository;
        this.userRoleRepository = userRoleRepository;
        this.moduleRepository = moduleRepository;
        this.permissionRepository = permissionRepository;
        this.userTokenService = userTokenService;
        this.emailAsyncService = emailAsyncService;
        this.emailTemplateService = emailTemplateService;
        this.serviceUtil = serviceUtil;
        this.encodeDecodeUtil = encodeDecodeUtil;
    }

    @Override
    public void run(String... args) {
        Optional<Role> adminRole = Optional.ofNullable(fetchAdminRole());
        if(adminRole.isPresent()) {
            provideAdminPermissionsToRole(adminRole.get());
            Set<UserRole> adminUsers = userRoleRepository.findAllByRole_SystemName(ADMIN_ROLE);
            if(CollectionUtils.isEmpty(adminUsers)) {
                User adminUser1 = createAdminUser("Vivek Jeswani", "vivek_bi@yopmail.com");
                LOGGER.info("Admin1 saved!");
                User adminUser2 = createAdminUser("Ronak Ruparell", "ronak_bi@yopmail.com");
                LOGGER.info("Admin2 saved!");

                assignAdminRoleToUser(adminUser1, adminRole.get());
                LOGGER.info("Admin1 given role admin with All permissions!");
                assignAdminRoleToUser(adminUser2, adminRole.get());
                LOGGER.info("Admin2 given role admin with All permissions!");

                UserToken token1 = generateUserToken(adminUser1);
                LOGGER.info("Set Password Token created & stored for Admin user 1");
                UserToken token2 = generateUserToken(adminUser2);
                LOGGER.info("Set Password Token created & stored for Admin user 2");

                EmailTemplate emailTemplate = emailTemplateService.findTemplateByName(NEW_REGISTRATION_EMAIL_TEMPLATE_NAME);
                String decodedEmailTemplate = encodeDecodeUtil.decodeData(emailTemplate.getBodyHtml());
                var valuesMap1 = prepareEmailVariableValues(adminUser1.getName(), adminRole.get().getName(), token1.getToken());
                var content1 = doContentReplacement(decodedEmailTemplate, valuesMap1);
                var valuesMap2 = prepareEmailVariableValues(adminUser2.getName(), adminRole.get().getName(), token2.getToken());
                var content2 = doContentReplacement(decodedEmailTemplate, valuesMap2);

                //TODO: send the user an email a token to verify the admin & set password
                sendEmailToAdmins(adminUser1.getEmail(), emailTemplate.getSubject(), content1);
                LOGGER.info("Email with Set password link sent to Admin user 1");
                sendEmailToAdmins(adminUser2.getEmail(), emailTemplate.getSubject(), content2);
                LOGGER.info("Email with Set password link sent to Admin user 2");
            }
        }
    }

    private void provideAdminPermissionsToRole(Role role) {
        List<Module> allModules = moduleRepository.findAllByParentModuleIsNull();
        Permission permission = permissionRepository.findPermissionByPermissionName("ALL");
        for(Module parentModule : allModules) {
            RolePermission rolePermission = RolePermission.builder().role(role).module(parentModule).permission(permission).build();
            rolePermissionRepository.save(rolePermission);
        }
    }

    private Role fetchAdminRole(){
        if(roleRepository.existsBySystemName(ADMIN_ROLE)){
            return roleRepository.findRoleBySystemName(ADMIN_ROLE);
        }
        return null;
    }

    private User createAdminUser(String name, String email) {
        User user = User.builder().name(name).email(email).status(Status.INACTIVE).password(null).build();
        return userRepository.save(user);
    }

    private UserToken generateUserToken(User user) {
        UserToken token = userTokenService.generateUniqueToken(user, TokenType.NEW_REGISTRATION);
        return userTokenService.saveUserToken(token);
    }

    private void assignAdminRoleToUser(User adminUser, Role adminRole) {
        UserRole userRole = UserRole.builder().user(adminUser).role(adminRole).build();
        userRoleRepository.save(userRole);
    }

    private Map<String, String> prepareEmailVariableValues(String adminName, String roleName, String token) {
        return Map.ofEntries(
                entry("first_name", adminName),
                entry("role_name", roleName),
                entry("set_password_link_with_token", baseUrl + contextPath + "/set-password/" + token)
        );
    }

    private String doContentReplacement(String emailContent, Map<String, String> emailArgsMap) {
        //TODO: decode the base64 encoded email content & use it for further replacement activity
        return serviceUtil.replaceMailContent(emailContent, emailArgsMap);
    }

    void sendEmailToAdmins(String adminEmail, String subject, String content) {
        EmailArgs emailArgs = EmailArgs.builder().toRecipients(Arrays.asList(adminEmail))
                .content(content)
                .subject(subject)
                .build();
        emailAsyncService.sendEmailThroughWebClient(sendEmailApiPath, MediaType.APPLICATION_JSON,emailArgs);
    }
}
