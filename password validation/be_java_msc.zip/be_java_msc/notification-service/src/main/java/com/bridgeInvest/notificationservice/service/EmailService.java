package com.bridgeInvest.notificationservice.service;

import com.bridgeInvest.notificationservice.model.EmailArgs;

public interface EmailService {

    void sendMail(EmailArgs emailArgs);
}
