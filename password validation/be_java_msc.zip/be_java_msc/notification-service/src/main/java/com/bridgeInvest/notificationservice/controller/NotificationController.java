package com.bridgeInvest.notificationservice.controller;

import com.bridgeInvest.notificationservice.model.EmailArgs;
import com.bridgeInvest.notificationservice.service.EmailService;
import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
@Api(tags="Notification API")
public class NotificationController {

    private final EmailService emailService;

    public NotificationController(EmailService emailService) {
        this.emailService = emailService;
    }

    @PostMapping(value = "/users", consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Create a new user")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(schema = @Schema(example = "{\"name\": \"xyz \", \"email\": \"xyz.doe@example.com\"}")))
    @ApiResponse(responseCode = "201", description = "User created")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    public void createUser() {
        // Method implementation
    }

    @PostMapping(value = "/send-email")
    @Operation(summary = "Send email")
    public void sendEmail(@RequestBody EmailArgs emailArgs) {
        emailService.sendMail(emailArgs);
    }
}
