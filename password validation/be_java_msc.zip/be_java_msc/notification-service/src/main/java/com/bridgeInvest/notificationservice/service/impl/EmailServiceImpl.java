package com.bridgeInvest.notificationservice.service.impl;

import com.bridgeInvest.notificationservice.model.EmailArgs;
import com.bridgeInvest.notificationservice.service.EmailService;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import java.io.File;

@Service
public class EmailServiceImpl implements EmailService {
    private static final Logger LOGGER = LoggerFactory.getLogger(EmailServiceImpl.class);
    private final JavaMailSender javaMailSender;
    private final Environment environment;

    public EmailServiceImpl(JavaMailSender javaMailSender, Environment environment) {
        this.javaMailSender = javaMailSender;
        this.environment = environment;
    }

    @Override
    public void sendMail(EmailArgs emailArgs) {
        if(!CollectionUtils.isEmpty(emailArgs.getToRecipients())) {

            try {
                String htmlContent = emailArgs.getContent();

                MimeMessage mimeMessage = javaMailSender.createMimeMessage();
                MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);

                mimeMessageHelper.setFrom(environment.getProperty("spring.from.mail"));
                mimeMessageHelper.setSubject(emailArgs.getSubject());
                mimeMessageHelper.setText(htmlContent, true);

                //setting TO addresses
                InternetAddress[] addresses = new InternetAddress[emailArgs.getToRecipients().size()];
                for (int i = 0; i < emailArgs.getToRecipients().size(); i++) {
                    addresses[i] = new InternetAddress(emailArgs.getToRecipients().get(i));
                }
                mimeMessageHelper.setTo(addresses);

                //setting CC addresses
                if(emailArgs.getCcRecipients() != null && !emailArgs.getCcRecipients().isEmpty()) {
                    addresses = new InternetAddress[emailArgs.getCcRecipients().size()];
                    for (int i = 0; i < emailArgs.getCcRecipients().size(); i++) {
                        addresses[i] = new InternetAddress(emailArgs.getCcRecipients().get(i));
                    }
                    mimeMessageHelper.setCc(addresses);
                }

                //setting BCC addresses
                if(emailArgs.getBccRecipients() != null && !emailArgs.getBccRecipients().isEmpty()) {
                    addresses = new InternetAddress[emailArgs.getBccRecipients().size()];
                    for (int i = 0; i < emailArgs.getCcRecipients().size(); i++) {
                        addresses[i] = new InternetAddress(emailArgs.getBccRecipients().get(i));
                    }
                    mimeMessageHelper.setBcc(addresses);
                }

                //setting attachments
                if(emailArgs.getAttachments() != null && !emailArgs.getAttachments().isEmpty()) {
                    for (String attachment : emailArgs.getAttachments()) {
                        FileSystemResource file = new FileSystemResource(new File(attachment));
                        mimeMessageHelper.addAttachment(file.getFilename(),file);
                    }
                }
                javaMailSender.send(mimeMessage);
                LOGGER.info("Email Sent Successfully");
            } catch (MessagingException e) {
                LOGGER.info(e.getMessage());
            } catch (Exception e) {
                LOGGER.info(e.getMessage());
            }
        }
    }
}
