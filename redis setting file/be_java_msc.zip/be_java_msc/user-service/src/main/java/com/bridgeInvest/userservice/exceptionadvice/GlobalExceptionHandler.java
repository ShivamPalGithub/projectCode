package com.bridgeInvest.userservice.exceptionadvice;
import com.bridgeInvest.userservice.constant.UserConstant;
import com.bridgeInvest.userservice.exception.UserException;
import io.jsonwebtoken.io.IOException;
import org.springframework.boot.json.JsonParseException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.time.DateTimeException;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(value = UserException.class)
    public ResponseEntity<String> handleUserException(UserException userException) {
         return new ResponseEntity<String>(userException.getErrorMessage(),userException.getErrorCode());
    }
    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        return new ResponseEntity<Object>(UserConstant.METHOD_INCORRECT, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = SQLException.class)
    protected ResponseEntity<Object> handleSQLException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = NullPointerException.class)
    protected ResponseEntity<Object> handleNullPointerException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = IOException.class)
    protected ResponseEntity<Object> handleIOException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = IllegalArgumentException.class)
    protected ResponseEntity<Object> handleIllegalArgumentException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = ArrayIndexOutOfBoundsException.class)
    protected ResponseEntity<Object> handleArrayIndexOutOfBoundsException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = FileNotFoundException.class)
    protected ResponseEntity<Object> handleFileNotFoundException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = DateTimeException.class)
    protected ResponseEntity<Object> handleDateTimeException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

    @ExceptionHandler(value = EnumConstantNotPresentException.class)
    protected ResponseEntity<Object> handleEnumConstantNotPresentException(UserException userException) {
        return new ResponseEntity<Object>(userException.getErrorMessage(), userException.getErrorCode());
    }

}