package com.bridgeInvest.userservice.controller;

import com.bridgeInvest.userservice.model.dto.EntityResponse;
import com.bridgeInvest.userservice.service.PermissionService;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.UUID;

@RestController
@RequestMapping("/api/V1/staff/permission")
public class PermissionController {

    private final PermissionService permissionService;

    public PermissionController(PermissionService permissionService) {
        this.permissionService = permissionService;
    }

    @GetMapping("/fetch-all")
    @ApiResponse(responseCode = "200", description = "Permissions fetched successfully")
    public EntityResponse getAllPermissions() {
        return permissionService.fetchAllPermissions();
    }

    @GetMapping("/find-by-id/{permission_id}")
    public EntityResponse findPermissionById(@PathVariable("permission_id") UUID permissionId) {
        return permissionService.fetchPermissionById(permissionId);
    }
}
