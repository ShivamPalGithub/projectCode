package com.bridgeInvest.userservice.model.dto;

import lombok.*;
import java.util.List;
import java.util.UUID;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class RolePermissionModel {
    private List<UUID> modulePermissionList;
}
