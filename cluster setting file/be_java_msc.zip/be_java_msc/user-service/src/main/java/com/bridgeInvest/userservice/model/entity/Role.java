package com.bridgeInvest.userservice.model.entity;

import com.bridgeInvest.userservice.model.dto.BaseEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import java.util.UUID;

@Entity
@Table(name="roles")
@SuperBuilder(toBuilder = true)
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Role extends BaseEntity {
    public Role(String name) {
        this.id = UUID.randomUUID();
        this.systemName = name.toUpperCase().replace(" ", "_");
        this.name = name;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "role_id")
    private UUID id;
    private String systemName;
    @Column(name = "role_name")
    private String name;

}
