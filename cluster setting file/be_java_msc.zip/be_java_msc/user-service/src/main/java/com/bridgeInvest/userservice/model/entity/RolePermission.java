package com.bridgeInvest.userservice.model.entity;

import com.bridgeInvest.userservice.model.dto.BaseEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import java.util.UUID;

@Entity
@Table(name="roles_permission")
@Getter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class RolePermission extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "role_permission_id")
    private UUID id;
    @ManyToOne
    @JoinColumn(name = "roles_id_fk")
    private Role role;
    @ManyToOne
    @JoinColumn(name = "permission_id_fk")
    private Permission permission;
    @ManyToOne
    @JoinColumn(name = "module_id_fk")
    private Module module;
}
