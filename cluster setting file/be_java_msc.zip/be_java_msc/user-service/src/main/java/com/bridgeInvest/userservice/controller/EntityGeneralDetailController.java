package com.bridgeInvest.userservice.controller;

import com.bridgeInvest.userservice.model.dto.EntityGeneralDetailModel;
import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/V1/grid")
@Api(tags="Entity Grid API")
public class EntityGeneralDetailController {

    private MessageSource messageSource;

    public EntityGeneralDetailController(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    @DeleteMapping(value = "/delete-entity", consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Delete entity")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(schema = @Schema(example = "{\"entityId\": \"id1\"}")))
    @ApiResponse(responseCode = "200", description = "Deleted successfully")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "204", description = "No such Data")
    public ResponseEntity deleteEntity(@RequestParam String entityId) {
        //Todo delete entity and its associated contacts
        return ResponseEntity.ok(messageSource.getMessage("entity.successfully.deleted", null, LocaleContextHolder.getLocale()) + " " + entityId);
    }

    @GetMapping(value = "/request-delete", consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Requesting deletion of entity")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(schema = @Schema(example = "{\"entityId\": \"id1\"}")))
    @ApiResponse(responseCode = "200", description = "Requested successfully")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "204", description = "No such Data")
    public ResponseEntity requestForDeletion(@RequestParam String entityId) {
        //Todo staff-member can request to super admin for deletion of entity
        return ResponseEntity.ok(messageSource.getMessage("notification.sent.successfully", null, LocaleContextHolder.getLocale()));
    }

    @PostMapping("/add/entity")
    @ApiResponse(responseCode = "201", description = "User created")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @Operation(summary = "Add new entity")
    public ResponseEntity<EntityGeneralDetailModel> create(@RequestBody EntityGeneralDetailModel entityGeneralDetailDTO) {
        //Todo:validate & save the entity return the entity DTO
        return new ResponseEntity<>(entityGeneralDetailDTO, HttpStatus.CREATED);
    }

    @GetMapping("/fetch/entities")
    @ApiResponse(responseCode = "200", description = "Successful")
    @Operation(summary = "Fetch all entities")
    public ResponseEntity<List<EntityGeneralDetailModel>> fetchAll() {
        //Todo: fetch all the entities return the list of entity DTOs
        return new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
    }
}