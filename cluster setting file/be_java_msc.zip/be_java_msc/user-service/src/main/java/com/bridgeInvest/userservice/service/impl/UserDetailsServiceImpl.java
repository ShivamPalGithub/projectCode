package com.bridgeInvest.userservice.service.impl;

import com.bridgeInvest.userservice.constant.UserConstant;
import com.bridgeInvest.userservice.exception.UserException;
import com.bridgeInvest.userservice.model.entity.User;
import com.bridgeInvest.userservice.respository.UserRepository;
import com.bridgeInvest.userservice.service.UserInfoUserDetails;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import java.util.Optional;

/**
 * Custom UserDetailsService implementation that retrieves user information from UserRepository.
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {
    private final UserRepository repository;

    public UserDetailsServiceImpl(UserRepository repository) {
        this.repository = repository;
    }
    /**
     * Loads user details by username.
     *
     * @param username The username of the user.
     * @return The UserDetails object representing the user details.
     * @throws UsernameNotFoundException If user is not found.
     */
    @Override
    public UserDetails loadUserByUsername(String username)   {
        Optional<User> userInfo = repository.findByName(username);
        return userInfo.map(UserInfoUserDetails::new)
        .orElseThrow(() -> new   UserException(HttpStatus.NOT_FOUND,UserConstant.RECORD_NOT_FOUND + username));

    }
}
