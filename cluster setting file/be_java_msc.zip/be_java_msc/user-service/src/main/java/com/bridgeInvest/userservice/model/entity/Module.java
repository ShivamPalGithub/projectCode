package com.bridgeInvest.userservice.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import java.util.UUID;

@Entity
@Table(name = "modules")
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Module {
    @Id
    @GeneratedValue
    @Column(name = "module_id")
    private UUID id;
    @Column(name = "module_name")
    private String moduleName;
    @OneToOne
    @JoinColumn(name = "parent_module_id")
    private Module parentModule;
}
