package com.bridgeInvest.userservice.constant;

public class UserConstant {

}
