package com.bridgeInvest.userservice.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import java.util.UUID;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EntityGeneralDetailModel {

    private UUID id;
    private String entityName;
    private String entityMemo;
    private String primaryRm;
    private String secondaryRm;
    private Boolean blacklisted;
    private String blacklistedReason;
    private String status;
    private String source;
    private Double feeExpectation;
    private String website;
    private String email;
    private String switchboard;
    private String address;

}
