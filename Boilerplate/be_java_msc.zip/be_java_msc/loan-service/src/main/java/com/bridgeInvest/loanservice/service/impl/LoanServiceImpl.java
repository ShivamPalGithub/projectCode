package com.bridgeInvest.loanservice.service.impl;

public class LoanServiceImpl {
}
