package com.bridgeInvest.notificationservice.service.impl;

public class NotificationServiceImpl {
}
