package com.bridgeInvest.userservice.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "roles")
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "role_id")
    private  UUID id;
    @Column(name = "role_name")
    private  String roleName;
    @Column(name = "status")
    private String status;
    @Column(name = "created_By")
    private String createdBy;
    @Column(name = "updated_By")
    private String updatedBy;
    @Column(name = "created_At")
    private String createdAt;
    @Column(name = "updated_At")
    private  String updatedAt;
    @Column(name = "contact_type")
    private  String contacttype;
    
}
