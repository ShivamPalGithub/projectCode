package com.bridgeInvest.userservice.model.dto;

import com.bridgeInvest.userservice.constant.enums.Status;
import com.bridgeInvest.userservice.model.entity.User;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import java.time.LocalDateTime;
import java.util.UUID;
@Getter
@Builder
@AllArgsConstructor
public class RolePermissionDTOModel {

    private Status status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private User createdBy;
    private User updatedBy;
    private UUID id;
    @JsonIgnore
    private RoleModel role;
    private PermissionDtoModel permission;
    private ModuleDtoModel module;
}
