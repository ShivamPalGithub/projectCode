package com.bridgeInvest.userservice.model.entity;

import com.bridgeInvest.userservice.model.dto.BaseEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import java.util.UUID;

@Entity
@Table(name="roles_permission")
@SuperBuilder
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class RolePermission extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "role_permission_id")
    private UUID id;
    @ManyToOne
    @JoinColumn(name = "roles_id")
    private Role role;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
}
