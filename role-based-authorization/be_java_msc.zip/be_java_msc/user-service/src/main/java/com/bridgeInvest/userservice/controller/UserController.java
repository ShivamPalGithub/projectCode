package com.bridgeInvest.userservice.controller;

import com.bridgeInvest.userservice.model.entity.User;
import com.bridgeInvest.userservice.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * Controller class for handling user-related endpoints.
 */
@RestController
@RequestMapping("/api/V1/user")
public class UserController {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);
    private final UserService userService;

    private final BCryptPasswordEncoder bCryptPasswordEncoder;

    /**
     * Constructs a new UserController with the provided UserService.
     *
     * @param userService The UserService instance.
     */
    public UserController(UserService userService, BCryptPasswordEncoder bCryptPasswordEncoder) {
        this.userService = userService;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }

    /**
     * Retrieves a list of all users.
     *
     * @return A list of User objects.
     */
    @PreAuthorize("hasAnyRole('ADMIN','SUPER-ADMIN')")
//   @PreAuthorize("hasRole('SUPER-ADMIN')")
    @GetMapping("/getall")
    public List<User> getall() {
        LOGGER.info("UserController -> getall method called");
        return userService.getallUser();
    }

    /**
     * Create a new user.
     *
     * @param user The user object containing the user information.
     * @return ResponseEntity indicating the result of the operation.
     * If the username already exists, a bad request response with an error message is returned.
     * If the user is successfully registered, an OK response is returned.
     */
    @PostMapping("/create")
    public ResponseEntity<String> create(@RequestBody User user) {
        if (userService.getUserByEmail(user.getEmail()).isPresent()) {
            LOGGER.debug("Username already exists");
            return ResponseEntity.badRequest().body("Username already exists");
        } else {
            //encoding password with bCryptPasswordEncoder
            user = User.builder().
                    email(user.getEmail()).
                    password(this.bCryptPasswordEncoder.encode(user.getPassword())).build();
            // Save the user
            userService.createUser(user);
            LOGGER.error("User registered successfully");
            return ResponseEntity.ok("User registered successfully");
        }
    }
}
