package com.bridgeInvest.userservice.controller;

import com.bridgeInvest.userservice.model.dto.ContactDependencyModel;
import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/V1/grid")
@Api(tags="Entity Grid API")
public class EntityGeneralDetailController {

    private MessageSource messageSource;

    public EntityGeneralDetailController(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    @DeleteMapping(value = "/delete-entity", consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Delete entity")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(schema = @Schema(example = "{\"entityId\": \"id1\"}")))
    @ApiResponse(responseCode = "200", description = "Deleted successfully")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "204", description = "No such Data")
    public ResponseEntity deleteMultipleContacts(@RequestParam String entityId){
        //Todo delete entity and its associated contacts
        return ResponseEntity.ok(messageSource.getMessage("entity.successfully.deleted",null, LocaleContextHolder.getLocale()) + " " + entityId);
    }

    @GetMapping(value = "/request_delete", consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Requesting deletion of entity")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(schema = @Schema(example = "{\"entityId\": \"id1\"}")))
    @ApiResponse(responseCode = "200", description = "Requested successfully")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "204", description = "No such Data")
    public ResponseEntity requestForDeletion(@RequestParam String entityId){
        //Todo staff-member can request to super admin for deletion of entity
        return ResponseEntity.ok(messageSource.getMessage("notification.sent.successfully",null, LocaleContextHolder.getLocale()));
    }

    @GetMapping(value = "/check-contact-dependency", consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Checking global level dependency of a contact")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(schema = @Schema(example = "{\"contactId\": \"id1\"}")))
    @ApiResponse(responseCode = "200", description = "Success")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "204", description = "No such Data")
    public ResponseEntity globalLevelContactDependency(@RequestParam String contactId){
        //Todo check that given contact is present in how many other entities,in which contact types and in which module
        ContactDependencyModel result = ContactDependencyModel.builder().build();
        return ResponseEntity.ok(messageSource.getMessage("notification.sent.successfully",null, LocaleContextHolder.getLocale()) + " " + result);
    }
}
