package com.bridgeInvest.userservice.controller;

import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/V1/contact")
@Api(tags="Contact Apis")
public class ContactController {

    @DeleteMapping(value = "/delete-contacts", consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Delete multiple contacts")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(schema = @Schema(example = "{\"contactIds\": [\"id1\", \"id2\", \"id3\"]}")))
    @ApiResponse(responseCode = "200", description = "Deleted successfully")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "204", description = "No such Data")
    public ResponseEntity deleteMultipleContacts(@RequestBody List<String> contactIds){
        //Todo delete multiple contacts
        return new ResponseEntity<>(contactIds,HttpStatus.OK);
    }
}
