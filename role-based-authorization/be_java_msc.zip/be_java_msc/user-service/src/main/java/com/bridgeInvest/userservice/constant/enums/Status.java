package com.bridgeInvest.userservice.constant.enums;

public enum Status {
    DELETED,
    ACTIVE,
    INACTIVE
}
