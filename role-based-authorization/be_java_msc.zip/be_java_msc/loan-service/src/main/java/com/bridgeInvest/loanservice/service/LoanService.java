package com.bridgeInvest.loanservice.service;

public interface LoanService {
}
