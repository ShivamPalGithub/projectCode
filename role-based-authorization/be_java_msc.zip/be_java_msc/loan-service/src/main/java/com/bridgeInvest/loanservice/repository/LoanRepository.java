package com.bridgeInvest.loanservice.repository;

public interface LoanRepository {
}
